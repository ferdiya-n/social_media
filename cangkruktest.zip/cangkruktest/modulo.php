<?php
	for ($i=1; $i < 101 ; $i++) { 
		if ($i % 3 == 0) echo " hai<br><br>";
		
		elseif ($i % 5 == 0) echo " hello<br><br>";
		
		elseif ($i % 7 == 0) echo " Chin<br><br>";
		
		else echo $i."<br><br>";
	}
?>