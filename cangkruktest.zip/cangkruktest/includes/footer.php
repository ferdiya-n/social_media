<script>
    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>
<div class="footer" style="
margin: 10px 50px;
padding: 10px;
color: white;
text-align: center;
border-top: 1px solid white;
">
    Cangkruk &copy; All rights reserved.
</div>
